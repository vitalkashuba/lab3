import azure.functions as func
import os, json, logging
from azure.servicebus import ServiceBusClient, ServiceBusMessage

SB_CONN_STR = os.environ["SERVICE_BUS_CONNECTION_STRING"]
QUEUE_NAME = os.environ.get("SERVICE_BUS_QUEUE", "iot-sensor-queue")

def main(req: func.HttpRequest) -> func.HttpResponse:
    try:
        payload = req.get_json()
    except Exception:
        return func.HttpResponse("Invalid JSON", status_code=400)

    # ensure fields
    payload.setdefault("sensorId", "unknown")
    payload.setdefault("sensorType", "unknown")
    payload.setdefault("value", None)
    payload.setdefault("unit", "")
    payload.setdefault("location", {"lat": 0.0, "lon": 0.0})
    payload.setdefault("timestamp", None)

    try:
        with ServiceBusClient.from_connection_string(SB_CONN_STR) as client:
            with client.get_queue_sender(QUEUE_NAME) as sender:
                sender.send_messages(ServiceBusMessage(json.dumps(payload)))
        return func.HttpResponse("Enqueued", status_code=200)
    except Exception as e:
        logging.exception("Failed to send to Service Bus")
        return func.HttpResponse(f"Send failed: {e}", status_code=500)
